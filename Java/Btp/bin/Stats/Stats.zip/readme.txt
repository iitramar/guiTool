The statistics are arranged as follows

Target_Concentration	Sample	Buffer	Waste	Operations
